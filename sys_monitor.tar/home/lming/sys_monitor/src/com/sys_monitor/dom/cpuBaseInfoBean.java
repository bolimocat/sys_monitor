package com.sys_monitor.dom;

public class cpuBaseInfoBean {
	private String cpuBaseInfo;

	public String getCpuBaseInfo() {
		return cpuBaseInfo;
	}

	public void setCpuBaseInfo(String cpuBaseInfo) {
		this.cpuBaseInfo = cpuBaseInfo;
	}


	

	
}
