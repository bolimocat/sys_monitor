package com.sys_monitor.dom;

public class linkInfoBean {
	private String linkInfo;

	public String getLinkInfo() {
		return linkInfo;
	}

	public void setLinkInfo(String linkInfo) {
		this.linkInfo = linkInfo;
	}
}
