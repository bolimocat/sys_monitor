package com.sys_monitor.dom;

public class ioBaseInfoBean {
	private String ioBaseInfo;

	public String getIoBaseInfo() {
		return ioBaseInfo;
	}

	public void setIoBaseInfo(String ioBaseInfo) {
		this.ioBaseInfo = ioBaseInfo;
	}
}
