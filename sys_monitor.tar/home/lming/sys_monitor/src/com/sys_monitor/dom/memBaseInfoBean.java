package com.sys_monitor.dom;

public class memBaseInfoBean {
	private String memBaseInfo;

	public String getMemBaseInfo() {
		return memBaseInfo;
	}

	public void setMemBaseInfo(String memBaseInfo) {
		this.memBaseInfo = memBaseInfo;
	}

}
