package com.sys_monitor.dom;

public class netBaseInfoBean {
	private String netBase;

	public String getNetBase() {
		return netBase;
	}

	public void setNetBase(String netBase) {
		this.netBase = netBase;
	}

	
}
