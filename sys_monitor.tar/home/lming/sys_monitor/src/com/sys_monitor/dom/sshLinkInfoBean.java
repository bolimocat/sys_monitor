package com.sys_monitor.dom;

public class sshLinkInfoBean {
	
	private String sshLinkInfo;

	public String getSshLinkInfo() {
		return sshLinkInfo;
	}

	public void setSshLinkInfo(String sshLinkInfo) {
		this.sshLinkInfo = sshLinkInfo;
	}
}
